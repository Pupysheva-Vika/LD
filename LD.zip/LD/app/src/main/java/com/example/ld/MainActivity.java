package com.example.ld;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private EditText edAnswer;
    private TextView tvE;
    private TextView tvPromt;
    private Button butAnswer;

    private int i =5;
    Random random = new Random();
    private int answer = random.nextInt(100);

    private void change(){
        answer = random.nextInt(100);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edAnswer = (EditText) findViewById(R.id.edAnswer);
        tvE = (TextView) findViewById(R.id.tvE);
        tvPromt = (TextView) findViewById(R.id.tvPromt);
        butAnswer = (Button) findViewById(R.id.butAnswer);
        tvE.setText(Integer.toString(i));
        butAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int fromAnswer;
                fromAnswer = Integer.parseInt(edAnswer.getText().toString());
                if(fromAnswer>answer){
                    tvPromt.setText("<");
                    i --;
                    tvE.setText(Integer.toString(i));
                }
                else if(fromAnswer<answer){
                    tvPromt.setText(">");
                    i--;
                    tvE.setText(Integer.toString(i));
                }
                else if(fromAnswer == answer){
                    tvPromt.setText("");
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("DRINK!!!");
                    builder.setPositiveButton("RETRY!!!!!", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    i =5;
                    tvE.setText(Integer.toString(i));
                    change();
                }
                if(i==0){
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("Luke, I'm your father! Answer: "+ Integer.toString(answer));
                    builder.setPositiveButton("Retry!", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    i =5;
                    tvE.setText(Integer.toString(i));
                    change();
                }

            }
        });

    }
}